//Nama               : Nurul Fitriani Zahra
//Nim                : 10122066
//Kelas              : Pemrograman Android 4
//tanggal pengerjaan : 10 Agustus2025

package com.example.resepmakanan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.resepmakanan.model.dummyResep
import com.example.resepmakanan.ui.theme.ResepmakananTheme
import com.example.resepmakanan.view.ResepDetailScreen
import com.example.resepmakanan.view.ResepListScreen

@OptIn(ExperimentalMaterial3Api::class)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ResepmakananTheme {
                val navController = rememberNavController()
                val resepList = dummyResep

                NavHost(navController = navController, startDestination = "resepList") {
                    composable("resepList") {
                        Scaffold(
                            topBar = {
                                TopAppBar(
                                    title = { Text("Daftar Resep", color = Color.White) },
                                    colors = TopAppBarDefaults.topAppBarColors(
                                        containerColor = Color(0xFF1976D2)
                                    )
                                )
                            }
                        ) { paddingValues ->
                            ResepListScreen(
                                resepList = resepList,
                                modifier = androidx.compose.ui.Modifier.padding(paddingValues),
                                onItemClick = { resepNama ->
                                    navController.navigate("resepDetail/$resepNama")
                                }
                            )
                        }
                    }

                    composable(
                        "resepDetail/{resepNama}",
                        arguments = listOf(navArgument("resepNama") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val resepNama = backStackEntry.arguments?.getString("resepNama")
                        val resep = resepList.find { it.nama == resepNama }

                        if (resep != null) {
                            ResepDetailScreen(
                                resep = resep,
                                onBackClick = { navController.navigateUp() }
                            )
                        }
                    }
                }
            }
        }
    }
}
