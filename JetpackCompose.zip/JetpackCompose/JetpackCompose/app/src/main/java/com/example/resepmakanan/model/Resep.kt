package com.example.resepmakanan.model

import com.example.resepmakanan.R

// Sebuah data class untuk menampung informasi resep
data class Resep(
    val nama: String,
    val gambar: Int,
    val bahan: List<String>,
    val langkah: List<String>
)

// Dummy data resep
val dummyResep = listOf(
    Resep(
        nama = "Nasi Goreng Spesial",
        gambar = R.drawable.nasgor,
        bahan = listOf(
            "Nasi putih",
            "Telur",
            "Ayam suwir",
            "Kecap manis",
            "Bawang merah, bawang putih"
        ),
        langkah = listOf(
            "Panaskan minyak, tumis bawang merah dan bawang putih hingga harum.",
            "Masukkan telur, orak-arik hingga matang.",
            "Masukkan nasi, aduk rata. Tambahkan kecap manis dan bumbu lainnya.",
            "Masak hingga semua bahan tercampur sempurna. Sajikan."
        )
    ),
    Resep(
        nama = "Sate Ayam Madura",
        gambar = R.drawable.sate,
        bahan = listOf(
            "Daging ayam",
            "Kacang tanah goreng",
            "Kecap manis",
            "Bawang merah",
            "Jeruk limau"
        ),
        langkah = listOf(
            "Potong daging ayam menjadi dadu, tusuk dengan tusukan sate.",
            "Bakar sate hingga setengah matang.",
            "Campurkan bumbu kacang, kecap, dan bawang merah untuk saus.",
            "Oleskan saus pada sate, bakar kembali hingga matang. Sajikan dengan lontong."
        )
    ),
    Resep(
        nama = "Rendang Sapi",
        gambar = R.drawable.rendang,
        bahan = listOf(
            "Daging sapi",
            "Santan kental",
            "Cabai merah",
            "Bawang merah, bawang putih",
            "Lengkuas, jahe, serai"
        ),
        langkah = listOf(
            "Haluskan bumbu: cabai, bawang merah, bawang putih, jahe, dan lengkuas.",
            "Tumis bumbu halus hingga harum. Masukkan daging sapi, aduk hingga berubah warna.",
            "Tuang santan, serai, dan daun-daun. Masak dengan api kecil hingga santan menyusut dan daging empuk.",
            "Aduk sesekali agar tidak gosong. Masak terus hingga rendang berwarna coklat kehitaman dan kering."
        )
    ),
    Resep(
        nama = "Soto Ayam Lamongan",
        gambar = R.drawable.soto,
        bahan = listOf(
            "Daging ayam",
            "Air",
            "Daun jeruk, serai",
            "Bawang merah, bawang putih",
            "Telur rebus, tauge, seledri"
        ),
        langkah = listOf(
            "Rebus ayam hingga matang, ambil kaldunya.",
            "Haluskan bumbu, tumis hingga harum. Masukkan ke dalam kaldu.",
            "Tambahkan daun jeruk dan serai. Masak hingga mendidih.",
            "Tata potongan ayam, telur, tauge, dan seledri di mangkuk. Siram dengan kuah soto.",
            "Sajikan dengan sambal dan perasan jeruk nipis."
        )
    ),
    Resep(
        nama = "Gado-Gado",
        gambar = R.drawable.gado_gado,
        bahan = listOf(
            "Sayuran (kangkung, tauge, kacang panjang)",
            "Tahu dan tempe",
            "Kentang rebus",
            "Lontong atau ketupat",
            "Bumbu kacang"
        ),
        langkah = listOf(
            "Rebus semua sayuran hingga matang, tiriskan.",
            "Goreng tahu dan tempe hingga kuning keemasan.",
            "Haluskan bumbu kacang atau gunakan bumbu instan. Encerkan dengan air panas.",
            "Tata semua bahan di piring, siram dengan bumbu kacang.",
            "Sajikan dengan taburan kerupuk dan bawang goreng."
        )
    ),
    Resep(
        nama = "Martabak Telur",
        gambar = R.drawable.martabak,
        bahan = listOf(
            "Kulit lumpia instan",
            "Telur",
            "Daging cincang",
            "Bawang bombay",
            "Daun bawang"
        ),
        langkah = listOf(
            "Campurkan telur, daging cincang, bawang bombay, dan daun bawang.",
            "Bumbui dengan garam dan merica. Aduk rata.",
            "Ambil selembar kulit lumpia, letakkan adonan telur di tengah.",
            "Lipat kulit lumpia hingga adonan tertutup rapat.",
            "Goreng di minyak panas hingga martabak matang dan berwarna coklat keemasan. Sajikan dengan saus cuka."
        )
    )
)